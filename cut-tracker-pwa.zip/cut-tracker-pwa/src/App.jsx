import React, { useState, useEffect } from 'react';
import { Dumbbell, Flame, TrendingDown, Plus, Trash2, Target, Calendar } from 'lucide-react';

// localStorage helpers
const storage = {
  get: (key) => {
    try {
      const v = localStorage.getItem(key);
      return v ? JSON.parse(v) : null;
    } catch { return null; }
  },
  set: (key, value) => {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
  },
  list: (prefix) => {
    const keys = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(prefix)) keys.push(k);
    }
    return keys;
  }
};

const App = () => {
  const [activeTab, setActiveTab] = useState('today');

  const [stats, setStats] = useState({
    weight: 195,
    targetCalories: 2300,
    proteinTarget: 195,
  });

  const [todayCalories, setTodayCalories] = useState([]);
  const [todayProtein, setTodayProtein] = useState(0);
  const [todayWorkout, setTodayWorkout] = useState(null);
  const [history, setHistory] = useState([]);

  const [foodName, setFoodName] = useState('');
  const [foodCals, setFoodCals] = useState('');
  const [foodProtein, setFoodProtein] = useState('');
  const [workoutType, setWorkoutType] = useState('Upper A');
  const [exercises, setExercises] = useState([{ name: '', sets: '', reps: '', weight: '' }]);

  const today = new Date().toISOString().split('T')[0];

  // Load on mount
  useEffect(() => {
    const s = storage.get('stats');
    if (s) setStats(s);

    const t = storage.get(`day:${today}`);
    if (t) {
      setTodayCalories(t.calories || []);
      setTodayProtein(t.protein || 0);
      setTodayWorkout(t.workout || null);
    }

    refreshHistory();
  }, []);

  const refreshHistory = () => {
    const keys = storage.list('day:').sort().reverse().slice(0, 14);
    const days = keys.map(k => {
      const data = storage.get(k);
      return data ? { date: k.replace('day:', ''), ...data } : null;
    }).filter(Boolean);
    setHistory(days);
  };

  const saveToday = (calories, protein, workout) => {
    const data = {
      calories: calories ?? todayCalories,
      protein: protein ?? todayProtein,
      workout: workout !== undefined ? workout : todayWorkout,
    };
    storage.set(`day:${today}`, data);
    refreshHistory();
  };

  const saveStats = (newStats) => {
    storage.set('stats', newStats);
  };

  const addFood = () => {
    if (!foodName || !foodCals) return;
    const entry = {
      name: foodName,
      cals: parseInt(foodCals) || 0,
      protein: parseInt(foodProtein) || 0,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    const newCalories = [...todayCalories, entry];
    const newProtein = todayProtein + entry.protein;
    setTodayCalories(newCalories);
    setTodayProtein(newProtein);
    saveToday(newCalories, newProtein);
    setFoodName('');
    setFoodCals('');
    setFoodProtein('');
  };

  const removeFood = (idx) => {
    const removed = todayCalories[idx];
    const newCalories = todayCalories.filter((_, i) => i !== idx);
    const newProtein = todayProtein - (removed.protein || 0);
    setTodayCalories(newCalories);
    setTodayProtein(newProtein);
    saveToday(newCalories, newProtein);
  };

  const totalCals = todayCalories.reduce((sum, f) => sum + f.cals, 0);
  const deficit = stats.targetCalories - totalCals;
  const calsPercent = Math.min(100, (totalCals / stats.targetCalories) * 100);
  const proteinPercent = Math.min(100, (todayProtein / stats.proteinTarget) * 100);

  const addExerciseRow = () => setExercises([...exercises, { name: '', sets: '', reps: '', weight: '' }]);
  const updateExercise = (idx, field, value) => {
    const updated = [...exercises];
    updated[idx][field] = value;
    setExercises(updated);
  };
  const removeExercise = (idx) => setExercises(exercises.filter((_, i) => i !== idx));

  const saveWorkout = () => {
    const filled = exercises.filter(e => e.name);
    if (filled.length === 0) return;
    const workout = { type: workoutType, exercises: filled };
    setTodayWorkout(workout);
    saveToday(null, null, workout);
    setExercises([{ name: '', sets: '', reps: '', weight: '' }]);
  };

  const clearWorkout = () => {
    setTodayWorkout(null);
    saveToday(null, null, null);
  };

  const weeklyDeficit = history.slice(0, 7).reduce((sum, d) => {
    const dayCals = (d.calories || []).reduce((s, f) => s + f.cals, 0);
    return sum + (stats.targetCalories - dayCals);
  }, 0);
  const fatLossPounds = (weeklyDeficit / 3500).toFixed(2);

  const exportData = () => {
    const allData = { stats, days: {} };
    storage.list('day:').forEach(k => {
      allData.days[k.replace('day:', '')] = storage.get(k);
    });
    const blob = new Blob([JSON.stringify(allData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cut-tracker-${today}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const tabBtn = (id, label, icon) => (
    <button
      onClick={() => setActiveTab(id)}
      style={{
        flex: 1,
        padding: '12px 8px',
        background: activeTab === id ? '#1e293b' : 'transparent',
        color: activeTab === id ? '#fff' : '#64748b',
        border: 'none',
        borderBottom: activeTab === id ? '2px solid #f97316' : '2px solid transparent',
        fontSize: '13px',
        fontWeight: '600',
        cursor: 'pointer',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: '4px'
      }}
    >
      {icon}
      {label}
    </button>
  );

  return (
    <div style={{ minHeight: '100vh', background: '#0a0a0a', color: '#fff', fontFamily: 'system-ui, -apple-system, sans-serif', paddingBottom: 'env(safe-area-inset-bottom, 20px)', paddingTop: 'env(safe-area-inset-top, 0)' }}>
      <div style={{ maxWidth: '600px', margin: '0 auto', padding: '16px' }}>
        <header style={{ marginBottom: '20px' }}>
          <h1 style={{ fontSize: '24px', fontWeight: '700', margin: 0, display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Target size={24} color="#f97316" />
            Cut Tracker
          </h1>
          <p style={{ color: '#64748b', fontSize: '13px', margin: '4px 0 0 0' }}>
            Get the abs. Stay accountable.
          </p>
        </header>

        <div style={{ display: 'flex', background: '#0f172a', borderRadius: '12px', marginBottom: '20px', overflow: 'hidden' }}>
          {tabBtn('today', 'Today', <Flame size={18} />)}
          {tabBtn('workout', 'Workout', <Dumbbell size={18} />)}
          {tabBtn('history', 'History', <Calendar size={18} />)}
          {tabBtn('settings', 'Settings', <TrendingDown size={18} />)}
        </div>

        {activeTab === 'today' && (
          <div>
            <div style={{ background: '#0f172a', borderRadius: '12px', padding: '20px', marginBottom: '16px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <span style={{ color: '#94a3b8', fontSize: '13px' }}>Calories</span>
                <span style={{ fontSize: '13px' }}>
                  <strong style={{ color: '#fff' }}>{totalCals}</strong>
                  <span style={{ color: '#64748b' }}> / {stats.targetCalories}</span>
                </span>
              </div>
              <div style={{ background: '#1e293b', height: '8px', borderRadius: '4px', overflow: 'hidden' }}>
                <div style={{ background: calsPercent > 100 ? '#ef4444' : '#f97316', height: '100%', width: `${calsPercent}%`, transition: 'width 0.3s' }} />
              </div>
              <div style={{ marginTop: '12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ color: '#94a3b8', fontSize: '13px' }}>Deficit</span>
                <span style={{ fontSize: '18px', fontWeight: '700', color: deficit >= 0 ? '#22c55e' : '#ef4444' }}>
                  {deficit >= 0 ? '-' : '+'}{Math.abs(deficit)} cal
                </span>
              </div>
            </div>

            <div style={{ background: '#0f172a', borderRadius: '12px', padding: '20px', marginBottom: '16px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <span style={{ color: '#94a3b8', fontSize: '13px' }}>Protein</span>
                <span style={{ fontSize: '13px' }}>
                  <strong style={{ color: '#fff' }}>{todayProtein}g</strong>
                  <span style={{ color: '#64748b' }}> / {stats.proteinTarget}g</span>
                </span>
              </div>
              <div style={{ background: '#1e293b', height: '8px', borderRadius: '4px', overflow: 'hidden' }}>
                <div style={{ background: '#3b82f6', height: '100%', width: `${proteinPercent}%`, transition: 'width 0.3s' }} />
              </div>
            </div>

            <div style={{ background: '#0f172a', borderRadius: '12px', padding: '16px', marginBottom: '16px' }}>
              <h3 style={{ margin: '0 0 12px 0', fontSize: '14px', color: '#94a3b8' }}>Add Food</h3>
              <input type="text" placeholder="Food name (e.g. Nurri protein drink)" value={foodName} onChange={(e) => setFoodName(e.target.value)} style={inputStyle} />
              <div style={{ display: 'flex', gap: '8px', marginTop: '8px' }}>
                <input type="number" inputMode="numeric" placeholder="Calories" value={foodCals} onChange={(e) => setFoodCals(e.target.value)} style={{ ...inputStyle, flex: 1 }} />
                <input type="number" inputMode="numeric" placeholder="Protein (g)" value={foodProtein} onChange={(e) => setFoodProtein(e.target.value)} style={{ ...inputStyle, flex: 1 }} />
              </div>
              <button onClick={addFood} style={primaryBtn}>
                <Plus size={16} /> Add Food
              </button>
            </div>

            {todayCalories.length > 0 && (
              <div style={{ background: '#0f172a', borderRadius: '12px', padding: '16px' }}>
                <h3 style={{ margin: '0 0 12px 0', fontSize: '14px', color: '#94a3b8' }}>Today's Food</h3>
                {todayCalories.map((f, i) => (
                  <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: i < todayCalories.length - 1 ? '1px solid #1e293b' : 'none' }}>
                    <div>
                      <div style={{ fontSize: '14px' }}>{f.name}</div>
                      <div style={{ fontSize: '11px', color: '#64748b' }}>
                        {f.time} • {f.cals} cal • {f.protein}g protein
                      </div>
                    </div>
                    <button onClick={() => removeFood(i)} style={{ background: 'transparent', border: 'none', color: '#ef4444', cursor: 'pointer', padding: '8px' }}>
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'workout' && (
          <div>
            {todayWorkout ? (
              <div style={{ background: '#0f172a', borderRadius: '12px', padding: '20px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                  <h3 style={{ margin: 0 }}>{todayWorkout.type} ✓</h3>
                  <button onClick={clearWorkout} style={{ background: 'transparent', border: '1px solid #1e293b', color: '#94a3b8', padding: '4px 12px', borderRadius: '6px', cursor: 'pointer', fontSize: '12px' }}>
                    Reset
                  </button>
                </div>
                {todayWorkout.exercises.map((ex, i) => (
                  <div key={i} style={{ padding: '10px 0', borderBottom: i < todayWorkout.exercises.length - 1 ? '1px solid #1e293b' : 'none' }}>
                    <div style={{ fontWeight: '600' }}>{ex.name}</div>
                    <div style={{ fontSize: '12px', color: '#64748b' }}>
                      {ex.sets} × {ex.reps} @ {ex.weight} lbs
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div style={{ background: '#0f172a', borderRadius: '12px', padding: '16px' }}>
                <h3 style={{ margin: '0 0 12px 0', fontSize: '14px', color: '#94a3b8' }}>Log Workout</h3>
                <select value={workoutType} onChange={(e) => setWorkoutType(e.target.value)} style={{ ...inputStyle, marginBottom: '12px' }}>
                  <option>Upper A</option>
                  <option>Lower A</option>
                  <option>Upper B</option>
                  <option>Lower B</option>
                  <option>Cardio/Walking Pad</option>
                </select>
                {exercises.map((ex, i) => (
                  <div key={i} style={{ marginBottom: '12px', padding: '12px', background: '#1e293b', borderRadius: '8px' }}>
                    <input type="text" placeholder="Exercise (e.g. Bench Press)" value={ex.name} onChange={(e) => updateExercise(i, 'name', e.target.value)} style={{ ...inputStyle, marginBottom: '8px' }} />
                    <div style={{ display: 'flex', gap: '6px' }}>
                      <input type="number" inputMode="numeric" placeholder="Sets" value={ex.sets} onChange={(e) => updateExercise(i, 'sets', e.target.value)} style={{ ...inputStyle, flex: 1 }} />
                      <input type="number" inputMode="numeric" placeholder="Reps" value={ex.reps} onChange={(e) => updateExercise(i, 'reps', e.target.value)} style={{ ...inputStyle, flex: 1 }} />
                      <input type="number" inputMode="numeric" placeholder="Weight" value={ex.weight} onChange={(e) => updateExercise(i, 'weight', e.target.value)} style={{ ...inputStyle, flex: 1 }} />
                      {exercises.length > 1 && (
                        <button onClick={() => removeExercise(i)} style={{ background: '#7f1d1d', border: 'none', color: '#fff', padding: '0 8px', borderRadius: '6px', cursor: 'pointer' }}>
                          <Trash2 size={14} />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
                <button onClick={addExerciseRow} style={{ ...primaryBtn, background: '#1e293b', marginBottom: '8px' }}>
                  <Plus size={16} /> Add Exercise
                </button>
                <button onClick={saveWorkout} style={primaryBtn}>
                  Save Workout
                </button>
              </div>
            )}
          </div>
        )}

        {activeTab === 'history' && (
          <div>
            <div style={{ background: '#0f172a', borderRadius: '12px', padding: '20px', marginBottom: '16px' }}>
              <h3 style={{ margin: '0 0 4px 0', fontSize: '14px', color: '#94a3b8' }}>Last 7 Days</h3>
              <div style={{ fontSize: '28px', fontWeight: '700', color: '#22c55e' }}>
                ~{fatLossPounds} lbs
              </div>
              <div style={{ fontSize: '12px', color: '#64748b' }}>
                Estimated fat loss from {weeklyDeficit.toLocaleString()} cal deficit
              </div>
            </div>

            {history.length === 0 ? (
              <div style={{ background: '#0f172a', borderRadius: '12px', padding: '20px', textAlign: 'center', color: '#64748b' }}>
                No history yet. Log some days.
              </div>
            ) : (
              history.map((d) => {
                const dayCals = (d.calories || []).reduce((s, f) => s + f.cals, 0);
                const dayDeficit = stats.targetCalories - dayCals;
                return (
                  <div key={d.date} style={{ background: '#0f172a', borderRadius: '12px', padding: '16px', marginBottom: '8px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                      <strong>{new Date(d.date + 'T12:00:00').toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' })}</strong>
                      <span style={{ color: dayDeficit >= 0 ? '#22c55e' : '#ef4444', fontWeight: '600' }}>
                        {dayDeficit >= 0 ? '-' : '+'}{Math.abs(dayDeficit)}
                      </span>
                    </div>
                    <div style={{ fontSize: '12px', color: '#64748b' }}>
                      {dayCals} cal • {d.protein || 0}g protein
                      {d.workout && ` • ${d.workout.type}`}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}

        {activeTab === 'settings' && (
          <div style={{ background: '#0f172a', borderRadius: '12px', padding: '20px' }}>
            <h3 style={{ margin: '0 0 16px 0', fontSize: '14px', color: '#94a3b8' }}>Targets</h3>
            <label style={labelStyle}>Bodyweight (lbs)</label>
            <input type="number" inputMode="numeric" value={stats.weight} onChange={(e) => { const v = { ...stats, weight: parseInt(e.target.value) || 0 }; setStats(v); saveStats(v); }} style={inputStyle} />
            <label style={labelStyle}>Daily Calorie Target</label>
            <input type="number" inputMode="numeric" value={stats.targetCalories} onChange={(e) => { const v = { ...stats, targetCalories: parseInt(e.target.value) || 0 }; setStats(v); saveStats(v); }} style={inputStyle} />
            <label style={labelStyle}>Daily Protein Target (g)</label>
            <input type="number" inputMode="numeric" value={stats.proteinTarget} onChange={(e) => { const v = { ...stats, proteinTarget: parseInt(e.target.value) || 0 }; setStats(v); saveStats(v); }} style={inputStyle} />

            <button onClick={exportData} style={{ ...primaryBtn, background: '#1e293b', marginTop: '20px' }}>
              Export Data (JSON Backup)
            </button>

            <div style={{ marginTop: '20px', padding: '12px', background: '#1e293b', borderRadius: '8px', fontSize: '12px', color: '#94a3b8', lineHeight: '1.5' }}>
              <strong style={{ color: '#f97316' }}>Quick math:</strong> 500 cal/day deficit ≈ 1 lb/week fat loss. At 195 lbs aiming for visible abs, hitting ~1g protein per lb bodyweight protects muscle during the cut.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const inputStyle = {
  width: '100%',
  background: '#1e293b',
  border: '1px solid #334155',
  color: '#fff',
  padding: '10px 12px',
  borderRadius: '8px',
  fontSize: '16px',
  fontFamily: 'inherit',
  boxSizing: 'border-box',
  outline: 'none',
};

const labelStyle = {
  display: 'block',
  fontSize: '12px',
  color: '#94a3b8',
  marginBottom: '6px',
  marginTop: '12px',
};

const primaryBtn = {
  width: '100%',
  background: '#f97316',
  border: 'none',
  color: '#fff',
  padding: '12px',
  borderRadius: '8px',
  fontSize: '14px',
  fontWeight: '600',
  cursor: 'pointer',
  marginTop: '12px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: '6px',
};

export default App;
